package spl;

import java.io.*;
import java.net.*;

public class LPClient {
    public static void main(String[] args) {
        // Check the number of command-line arguments
        if (args.length != 2) {
            System.err.println("Usage: java LPClient hostname port_number");
            System.exit(1);
        }

        String serverHostname = args[0]; // Server hostname
        int portNumber = Integer.parseInt(args[1]); // Server port number

        // Create a socket to connect to the server using try-with-resources
        try (Socket socket = new Socket(serverHostname, portNumber);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true); // abstraction for sending data to the server (output stream)
             BufferedReader in = new BufferedReader(new InputStreamReader(System.in))) {  // abstraction for reading data from the user (System input stream)
        
            // Read lines from System.in in a loop
            String line;
            while ((line = in.readLine()) != null) {
                // Send the line to the server
                out.println(line);
                System.out.println("Message sent to server: " + line);

                // If the user enters "bye", exit the loop
                if (line.equals("bye"))
                    break;
            }
        } catch (UnknownHostException e) {
            System.err.println("Unknown host: " + serverHostname);
            System.exit(1);
        } catch (IOException e) {
            System.err.println("I/O error: " + e.getMessage());
            System.exit(1);
        }
    }
}
