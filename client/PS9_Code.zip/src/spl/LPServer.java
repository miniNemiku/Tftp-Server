package spl;

import java.io.*;
import java.net.*;

class LPServer {
    public static void main(String[] args) {
        // Check the number of command-line arguments
        if (args.length != 1) {
            System.err.println("Usage: java LPServer port_number");
            System.exit(1);
        }
    
        int portNumber = Integer.parseInt(args[0]); // Server port number
    
        // Create a server socket to listen for incoming connections
        try (ServerSocket serverSocket = new ServerSocket(portNumber);
             Socket clientSocket = serverSocket.accept();                                                        // Accept the first incoming connection
             BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))) {     // Create a BufferedReader to read messages from the client

            // Read and print messages from the client in a loop
            String message;
            while ((message = in.readLine()) != null) {
                // If the client sends "bye", exit the loop
                if (message.equals("bye"))
                {
                    System.out.println("Client has requested to end the session.");
                    break;  
                }

                // Print the message on the line printer
                System.out.println("Message from client: " + message);
            }
    
        } catch (IOException e) {
            System.err.println("I/O error: " + e.getMessage());
            System.exit(1);
        }
      }
    }