package spl;

import java.io.*;
import java.net.*;

public class EchoClient {
	public static void main(String[] args) {
		// Check the number of command-line arguments
		if (args.length != 2) {
			System.err.println("Usage: java EchoClient hostname port_number");
			System.exit(1);
		}

		String serverHostname = args[0]; // Server hostname
		int portNumber = Integer.parseInt(args[1]); // Server port number

		// Create a socket to connect to the server using try-with-resources
		try (Socket socket = new Socket(serverHostname, portNumber);
				PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true);
				BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				BufferedReader userIn = new BufferedReader(new InputStreamReader(System.in))) {

			String line;
			while ((line = userIn.readLine()) != null) {
				out.println(line);
				System.out.println(in.readLine());
			}
		} catch (UnknownHostException e) {
			System.err.println("Unknown host: " + serverHostname);
			System.exit(1);
		} catch (IOException e) {
			System.err.println("I/O error: " + e.getMessage());
			System.exit(1);
		}
	}

}