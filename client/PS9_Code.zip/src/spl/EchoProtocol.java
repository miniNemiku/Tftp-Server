package spl;

public class EchoProtocol implements ServerProtocol {

    private int counter;

    public EchoProtocol() {
        counter = 0;
    }

    public String processMessage(String msg) {
        counter++;

        System.out.println(counter + ". Received \"" + msg + "\" from client");
        if (isEnd(msg))
            return new String("Ok, bye bye...");
        else
            return msg;
    }

    public boolean isEnd(String msg) {
        return msg.equals("bye");
    }
}