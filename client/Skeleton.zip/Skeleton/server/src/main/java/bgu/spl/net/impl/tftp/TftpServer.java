package bgu.spl.net.impl.tftp;

public class TftpServer {
    //TODO: Implement this
}
